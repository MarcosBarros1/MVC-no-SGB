from model.emprestimo import Emprestimo

class EmprestimoController:
    def __init__(self):
        self.model = Emprestimo()

    def emprestar(self, usuario_id, livro_id):
        return self.model.realizar_emprestimo(usuario_id, livro_id)

    def devolver(self, emprestimo_id):
        return self.model.realizar_devolucao(emprestimo_id)

    def listar(self):
        return self.model.listar_emprestimos()
