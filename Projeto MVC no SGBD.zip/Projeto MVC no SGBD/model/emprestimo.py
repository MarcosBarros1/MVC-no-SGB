import sqlite3
from datetime import datetime, timedelta

class Emprestimo:
    def __init__(self, db_path='D:/Projeto MVC no SGBD/BD/bd_mvc'):
        self.conn = sqlite3.connect(db_path)
        self.cursor = self.conn.cursor()

    def quantidade_emprestimos_usuario(self, usuario_id):
        self.cursor.execute("""
            SELECT COUNT(*) FROM emprestimos
            WHERE usuario_id = ? AND data_devolucao IS NULL
        """, (usuario_id,))
        return self.cursor.fetchone()[0]

    def livro_disponivel(self, livro_id):
        self.cursor.execute("""
            SELECT quantidade_disponivel FROM livros WHERE isbn = ?
        """, (livro_id,))
        resultado = self.cursor.fetchone()
        return resultado and resultado[0] > 0

    def realizar_emprestimo(self, usuario_id, livro_id):
        if self.quantidade_emprestimos_usuario(usuario_id) >= 3:
            return "Erro: Usuário já tem 3 livros emprestados."

        if not self.livro_disponivel(livro_id):
            return "Erro: Livro indisponível no estoque."

        data_emprestimo = datetime.now().date()
        data_prevista = data_emprestimo + timedelta(days=7)

        self.cursor.execute("""
            INSERT INTO emprestimos (usuario_id, livro_id, data_emprestimo, data_prevista, status)
            VALUES (?, ?, ?, ?, 'emprestado')
        """, (usuario_id, livro_id, data_emprestimo, data_prevista))

        self.cursor.execute("""
            UPDATE livros SET quantidade_disponivel = quantidade_disponivel - 1 WHERE isbn = ?
        """, (livro_id,))

        self.conn.commit()
        return "Empréstimo realizado com sucesso."

    def realizar_devolucao(self, emprestimo_id):
        data_devolucao = datetime.now().date()

        self.cursor.execute("""
            SELECT data_prevista, livro_id FROM emprestimos WHERE id = ?
        """, (emprestimo_id,))
        resultado = self.cursor.fetchone()

        if resultado:
            data_prevista, livro_id = resultado
            status = 'atrasado' if data_devolucao > datetime.strptime(data_prevista, '%Y-%m-%d').date() else 'devolvido'

            self.cursor.execute("""
                UPDATE emprestimos
                SET data_devolucao = ?, status = ?
                WHERE id = ?
            """, (data_devolucao, status, emprestimo_id))

            self.cursor.execute("""
                UPDATE livros SET quantidade_disponivel = quantidade_disponivel + 1 WHERE isbn = ?
            """, (livro_id,))

            self.conn.commit()
            return "Devolução realizada com sucesso."
        else:
            return "Erro: Empréstimo não encontrado."

    def listar_emprestimos(self):
        self.cursor.execute("""
            SELECT e.id, u.nome, l.titulo, e.data_emprestimo, e.data_prevista, e.data_devolucao, e.status
            FROM emprestimos e
            JOIN usuarios u ON e.usuario_id = u.matricula
            JOIN livros l ON e.livro_id = l.isbn
        """)
        return self.cursor.fetchall()
