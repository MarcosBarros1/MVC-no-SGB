from view.terminal_view import menu

if __name__ == "__main__":
    menu()
