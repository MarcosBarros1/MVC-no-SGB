from controller.emprestimo_controller import EmprestimoController

controller = EmprestimoController()

def menu():
    while True:
        print("\n===== MENU =====")
        print("1 - Realizar Empréstimo")
        print("2 - Realizar Devolução")
        print("3 - Listar Todos os Empréstimos")
        print("0 - Sair")

        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            usuario_id = input("Digite a matrícula do usuário: ")
            livro_id = input("Digite o ISBN do livro: ")
            resultado = controller.emprestar(usuario_id, livro_id)
            print(resultado)

        elif opcao == "2":
            emprestimo_id = input("Digite o ID do empréstimo para devolução: ")
            resultado = controller.devolver(emprestimo_id)
            print(resultado)

        elif opcao == "3":
            emprestimos = controller.listar()
            for e in emprestimos:
                print(f"ID: {e[0]} | Usuário: {e[1]} | Livro: {e[2]} | Empréstimo: {e[3]} | Previsto: {e[4]} | Devolução: {e[5]} | Status: {e[6]}")

        elif opcao == "0":
            break

        else:
            print("Opção inválida.")
